﻿using CRMEDU.Data.IRepositories;
using CRMEDU.Domain.Entities.Reporters;

namespace CRMEDU.Data.Repositories
{
    public class ReporterRepository : GenericRepository<Reporter>, IReporterRepository
    {
    }
}
