﻿using CRMEDU.Data.IRepositories;
using CRMEDU.Domain.Entities.Admins;

namespace CRMEDU.Data.Repositories
{
    public class AdminRepository : GenericRepository<Admin>, IAdminRepository
    {
    }
}
