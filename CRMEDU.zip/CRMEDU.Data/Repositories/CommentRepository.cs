﻿using CRMEDU.Data.IRepositories;
using CRMEDU.Domain.Commons;

namespace CRMEDU.Data.Repositories
{
    public class CommentRepository : GenericRepository<Comment>, ICommentRepository
    {
    }
}
