﻿using CRMEDU.Domain.Entities.Courses;

namespace CRMEDU.Data.IRepositories
{
    public interface IClassRepository : IGenericRepository<Class>
    {
    }
}
