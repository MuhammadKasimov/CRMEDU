﻿using CRMEDU.Domain.Entities.Teachers;

namespace CRMEDU.Data.IRepositories
{
    public interface ITeacherRepository : IGenericRepository<Teacher>
    {
    }
}
