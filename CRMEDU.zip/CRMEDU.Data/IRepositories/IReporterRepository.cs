﻿using CRMEDU.Domain.Entities.Reporters;

namespace CRMEDU.Data.IRepositories
{
    public interface IReporterRepository : IGenericRepository<Reporter>
    {
    }
}
