﻿using CRMEDU.Domain.Entities.ManyRelations;

namespace CRMEDU.Data.IRepositories
{
    public interface IClassReporterRepository : IGenericRepository<ClassReporter>
    {
    }
}
