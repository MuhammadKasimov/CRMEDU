﻿using CRMEDU.Domain.Entities.ManyRelations;

namespace CRMEDU.Data.IRepositories
{
    public interface IStudentClassRepository : IGenericRepository<StudentClass>
    {

    }
}