﻿using CRMEDU.Domain.Commons;

namespace CRMEDU.Data.IRepositories
{
    public interface ICommentRepository : IGenericRepository<Comment>
    {
    }
}
