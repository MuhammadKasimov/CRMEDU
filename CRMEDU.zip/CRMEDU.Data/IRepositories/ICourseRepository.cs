﻿using CRMEDU.Domain.Entities.Courses;

namespace CRMEDU.Data.IRepositories
{
    public interface ICourseRepository : IGenericRepository<Course>
    {
    }
}
