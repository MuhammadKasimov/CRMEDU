﻿using CRMEDU.Domain.Entities.Students;

namespace CRMEDU.Data.IRepositories
{
    public interface IStudentRepository : IGenericRepository<Student>
    {
    }
}
