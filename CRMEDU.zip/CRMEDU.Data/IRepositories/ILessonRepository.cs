﻿using CRMEDU.Domain.Entities.Lessons;

namespace CRMEDU.Data.IRepositories
{
    public interface ILessonRepository : IGenericRepository<Lesson>
    {
    }
}
