﻿using CRMEDU.Domain.Entities.Admins;

namespace CRMEDU.Data.IRepositories
{
    public interface IAdminRepository : IGenericRepository<Admin>
    {
    }
}
