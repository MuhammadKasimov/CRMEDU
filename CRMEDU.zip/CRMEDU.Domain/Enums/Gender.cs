﻿namespace CRMEDU.Domain.Enums
{
    public enum Gender
    {
        Male,
        Female
    }
}
