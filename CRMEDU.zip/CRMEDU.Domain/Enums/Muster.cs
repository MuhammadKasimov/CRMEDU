﻿namespace CRMEDU.Domain.Enums
{
    public enum Muster
    {
        AbsentWithout,
        AbsentWith,
        Present
    }
}
