﻿namespace CRMEDU.Domain.Enums
{
    public enum SentTo
    {
        Teacher,
        Student,
        Admin
    }
}