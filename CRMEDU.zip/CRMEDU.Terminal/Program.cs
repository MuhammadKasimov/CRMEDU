﻿using System.Threading.Tasks;

namespace CRMEDU.Terminal
{
    internal class Program
    {
        static async Task Main(string[] args)
        {
        }
    }
}
