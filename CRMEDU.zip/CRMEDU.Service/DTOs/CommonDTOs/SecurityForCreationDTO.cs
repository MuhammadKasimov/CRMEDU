﻿namespace CRMEDU.Service.DTOs.CommonDTOs
{
    public class SecurityForCreationDTO
    {
        public string Login { get; set; }
        public string Password { get; set; }
    }
}
